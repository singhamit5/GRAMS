-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 25, 2018 at 09:16 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `grams`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_name` varchar(15) NOT NULL,
  `cat_id` int(2) NOT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_name`, `cat_id`) VALUES
('Bike', 1),
('Book', 2),
('Car', 3),
('Mobile', 4),
('Laptop', 5),
('Furnishing', 6),
('Sports Item', 7),
('Accessories', 8),
('Clothing', 9),
('Electronics', 10);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `desp` varchar(500) NOT NULL,
  `price` int(8) NOT NULL,
  `cat` int(2) NOT NULL,
  `dt` varchar(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `img1` varchar(500) NOT NULL,
  PRIMARY KEY (`p_id`),
  KEY `name` (`name`),
  KEY `cat` (`cat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `title`, `desp`, `price`, `cat`, `dt`, `name`, `img1`) VALUES
(4, 'Dell Inspiron 5558', 'ksdbud fwft rethkr er kgjrhewjg jrehg werg kjr ghkwje r hgjrh gjwerhgk jerwh jrehg wj\r\nwefhv whjfwehr gkerj gkerg er\r\nwe gwerkgkerwg', 35000, 5, '22.03.2018 Thursday', 'amits3559', 'IMG_20180322_103010.jpg'),
(8, 'Coat', 'In good Condition', 500, 9, '23-03-2018 Friday', 'amits3559', 'IMG_20180322_103207.jpg'),
(12, 'BIKE HELMET', 'year of purchase is 2018 and only used 4 months .very comfortable ', 450, 8, '23-03-2018 Friday', 'ghirit kumar sahoo', 'IMG_20180323_130047.jpg'),
(13, 'VOLKS WAGAN', 'car is in good condition . year of purchase is 2015. only 63000 km driven. price is negotiable .', 300000, 3, '23-03-2018 Friday', 'ghirit kumar sahoo', 'IMG_20180323_130109.jpg'),
(14, 'FORD', 'car is in good condition. year of purchase 2015 .65000 km driven', 350000, 3, '23-03-2018 Friday', 'ghirit kumar sahoo', 'IMG_20180323_130112.jpg'),
(15, 'BAJAJ PULSAR', 'BIKE is in good condition. year of purchase 2015 .65000 km driven', 45000, 1, '23-03-2018 Friday', 'ghirit kumar sahoo', 'IMG_20180323_130132.jpg'),
(16, 'SCOOTY PLEASURE', 'SCOOTY is in good condition. year of purchase 2015 .65000 km driven', 35000, 1, '23-03-2018 Friday', 'ghirit kumar sahoo', 'IMG_20180323_130221.jpg'),
(17, 'AUDI', 'car is in good condition. year of purchase 2018 .9000 km driven', 900000, 3, '23-03-2018 Friday', 'ghirit kumar sahoo', 'IMG_20180323_130258.jpg'),
(18, 'CHAIR', 'ONLY 3 MONTHS OLD.', 600, 6, '23-03-2018 Friday', 'ravi', 'IMG_20180323_130659.jpg'),
(20, '32 gb pendrive', 'only 6 months old.', 900, 10, '23-03-2018 Friday', 'ravi', 'IMG_20180323_130727.jpg'),
(21, 'study table', 'year of purchase 8 months .higly maintained.', 2500, 6, '23-03-2018 Friday', 'ravi', 'IMG_20180323_130803.jpg'),
(22, 'CCTV CAMERA ', 'CAMERA IS IN GOOD CONDITION', 3000, 10, '23-03-2018 Friday', 'sibasis', 'IMG_20180323_130820.jpg'),
(23, 'CLOCK', 'CONDITION IS GOOD ', 400, 6, '23-03-2018 Friday', 'sibasis', 'IMG_20180323_130828.jpg'),
(24, 'PHONE COVER', 'ONLY 2 MONTHS OLD.', 150, 4, '23-03-2018 Friday', 'sibasis', 'IMG_20180323_130851.jpg'),
(25, 'DELL DESKTOP', 'YEAR OF PURCHASE 2015.CONDITION IS GOOD', 25000, 5, '23-03-2018 Friday', 'sibasis', 'IMG_20180323_130912.jpg'),
(26, 'PARAM SUPER COMPUTER', 'FASTEST COMPUTER AND IN GOOD CONDTION.', 2000000, 5, '23-03-2018 Friday', 'Rajneesh', 'IMG_20180323_131427.jpg'),
(27, 'WRIST WATCH', 'GOOD CONDITION', 1100, 9, '23-03-2018 Friday', 'Rajneesh', 'IMG_20180323_131521.jpg'),
(29, 'MOUSE', 'GOOD CONDITION.', 350, 5, '23-03-2018 Friday', 'Rajneesh', 'IMG_20180323_131542.jpg'),
(30, 'SHOES', 'GOOD CONDITION.', 650, 9, '23-03-2018 Friday', 'Rajneesh', 'IMG_20180323_131602.jpg'),
(31, 'BASKETBALL', 'GOOD CONDITION', 600, 7, '23-03-2018 Friday', 'ravi', 'IMG_20180322_103757.jpg'),
(32, 'Table Fan', 'In good Condition', 1500, 10, '23-03-2018 Friday', 'user123', 'IMG_20180322_103933.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(30) NOT NULL,
  `regd_no` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(13) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `regd_no`, `email`, `phone`, `password`) VALUES
('amits3559', 1501227252, 'amits3559@gmail.com', 2147483647, 'amits'),
('gdfgdf', 5435, 'gfdgfd@xcvcxv', 2147483647, '123'),
('ghirit kumar sahoo', 1501227276, 'ghiritsahoo046@gmail.com', 2147483647, 'Ghirit@123'),
('Rajneesh', 1501227025, 'rajneeshkr.309@gmail.com', 2147483647, '1234'),
('ravi', 1501227291, 'ravi@gmail.com', 2147483647, 'Ravi@123'),
('sibasis', 1501227027, 'dipu2597@gmail.com', 2147483647, '12345'),
('user123', 1501227252, 'a@gmail.com', 2147483647, 'Ghirit@123'),
('user456', 494949449, 'asdhb@fd', 2147483647, 'Amit@123');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`name`) REFERENCES `user` (`name`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`cat`) REFERENCES `category` (`cat_id`);
